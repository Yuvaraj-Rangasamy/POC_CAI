from setuptools import setup

setup(
  name='test',
  install_requires=['six'],
)
